function[] = Colorado_topo()
%-------------------------------------------------------------------------%
% 
% This function takes topographical data of Colorado and plots it in a way
% for visual representation. It can be run directly from the Command Window
% and can be modified to add additional cities within Colorado as well as
% long as their latitude and longitudes are know
% Zach Yearout
%-------------------------------------------------------------------------%
clear all; close all; clc;

%load data
Z = load('CO_topo.txt');
%Convert fom m to ft
[n,m]=size(Z);
for i = 1:n
    for j = 1:m
            Z(i,j) = Z(i,j) * 3.28083989501312;
    end
end
%plot square root of altitude
surf(Z.^(1/2),'EdgeColor','none');
title('Colorado')
xlabel('longitude index')
ylabel('latitude index')
zlabel('altitude [ft^{1/2}]')
%adjust view angle
view(6,78)
%adjust aspect ratio
pbaspect([380/280, 1, 1]);
%add Denver
hold on
Denver_lat =   39.7392;
Denver_lon = -104.9903;
[ib,jb]=get_coords(Denver_lat,Denver_lon);
plot3(jb,ib,Z(ib,jb)^0.5,'ko','MarkerFace','k')

end


function[i,j]=get_coords(lat,lon)
%----------------------------------------------------%
% Function get_coords returns the indicies
% for a desired latitude longitude coordinate
%
%----------------------------------------------------%
% define lat/lon for CO
latmin =   37.000000;
latmax =   41.000000;
lonmin = -109.050000;
lonmax = -102.016667;
%check boundaries
if (lon < lonmin || lon > lonmax )
    display('lon error')
    i = -999;
    j = -999;
return; end
if (lat < latmin || lat > latmax)
    display('lat error')
    i = -999;
    j = -999;
return; end
% grid box width
dlon   = 0.00833333334;
dlat   = dlon;
% calculate grid box indicies
i = floor((lat - latmin)/dlat)+1;
j = floor((lon - lonmin)/dlon)+1;
end