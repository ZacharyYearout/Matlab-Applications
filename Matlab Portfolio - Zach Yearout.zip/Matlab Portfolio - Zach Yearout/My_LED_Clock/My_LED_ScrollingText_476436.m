%%%%%%%%%%%%%%%%%%%%%%%%%%
% My_LED_ScrollingText_476436
%         by
%     Zach Yearout
%      476-436
%%%%%%%%%%%%%%%%%%%%%%%%%%

StringInput = ('hello world');
InputUpper = upper(StringInput);
InputLength = length(StringInput);
for ii = 1:InputLength
    InputNum(ii) = int8(InputUpper(ii))-64;
end

Word = zeros(5,1);
for jj = 1:InputLength
    if InputNum(jj) == -32
        InputNum(jj) = 27;
    end 
    Word = [Word,Alphabet{InputNum(jj)},Space];
end

% Dynamic Word
ScrollWord = [zeros(5,length(Word)),Word];
for tt = 1:2*length(Word)
    ScrollWord = circshift(ScrollWord,-1,2);
    for ii = 1:5
        for jj = 1:17
            if ScrollWord(ii,jj)==1
                set(H(ii,jj),'facecolor','g')
            else
                set(H(ii,jj),'facecolor','w')
            end
        end
    end
pause(0.1)    
MovieWord(tt) = getframe(gcf);
end

movie(MovieWord,5)
        