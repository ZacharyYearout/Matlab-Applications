%%%%%%%%%%%%%%%%%%%%%%%%%%
% My_LED_ScrollingClock_476436
%         by
%     Zach Yearout
%      476-436
%%%%%%%%%%%%%%%%%%%%%%%%%%
Time = clock;
Hour = Time(1,4)+0.01;
Minute = Time(1,5)+0.01;
format long

HourString = num2str(Hour/100);
MinuteString = num2str(Minute/100);
HourNum1= str2num(HourString(1,3));
if HourNum1 == 0
    HourNum1 = 10;
end
HourNum2= str2num(HourString(1,4));
if HourNum2 == 0
    HourNum2 = 10;
end
MinuteNum1 = str2num(MinuteString(1,3));
if MinuteNum1 == 0
    MinuteNum1 = 10;
end
MinuteNum2 = str2num(MinuteString(1,4));
if MinuteNum2 == 0
    MinuteNum2 = 10;
end
Clock = [Num{HourNum1},Space,Num{HourNum2},Space,...
    Colon,Space,Num{MinuteNum1},Space,...
    Num{MinuteNum2}];

% Static Clock
% for ii = 1:5
%     for jj = 1:17
%         if A(ii,jj)==1
%             set(H(ii,jj),'facecolor','g')
%         else
%             set(H(ii,jj),'facecolor','w')
%         end
%     end
% end

% Dynamic Clock
ScrollClock = [zeros(5,17),Clock];
for tt = 1:34
    ScrollClock = circshift(ScrollClock,-1,2);
    for ii = 1:5
        for jj = 1:17
            if ScrollClock(ii,jj)==1
                set(H(ii,jj),'facecolor','g')
            else
                set(H(ii,jj),'facecolor','w')
            end
        end
    end
pause(0.1)    
MovieClock(tt) = getframe(gcf);
end

movie(MovieClock,5)