%%%%%%%%%%%%%%%%%%%%%%%%%
% My_LED_Initialize
%This project displays the time or custom message and then exports it
%as a movie. The project works by first running My_LED_Initialize and
%then running either the My_LED_ScrollingClock or My_LED_ScrollingText.
%The message can be customized in the StringInput variable and the clock
%uses Matlab's internal clock function to display the current military time
% Zach Yearout
%%%%%%%%%%%%%%%%%%%%%%%%%%
R = 1;
close all
global Num Space Colon H Alphabet

Num=cell(10,1);
Num{1} = [0 1 0;0 1 0;0 1 0;0 1 0;0 1 0];
Num{2} = [1 1 1;0 0 1;1 1 1;1 0 0;1 1 1];
Num{3} = [1 1 1;0 0 1;1 1 1;0 0 1;1 1 1];
Num{4} = [1 0 1;1 0 1;1 1 1;0 0 1;0 0 1];
Num{5} = [1 1 1;1 0 0;1 1 1;0 0 1;1 1 1];
Num{6} = [1 1 1;1 0 0;1 1 1;1 0 1;1 1 1];
Num{7} = [1 1 1;1 0 1;0 0 1;0 0 1;0 0 1];
Num{8} = [1 1 1;1 0 1;1 1 1;1 0 1;1 1 1];
Num{9} = [1 1 1;1 0 1;1 1 1;0 0 1;1 1 1];
Num{10} = [1 1 1;1 0 1;1 0 1;1 0 1;1 1 1];
Space = [0;0;0;0;0];
Colon = [0;1;0;1;0];

Alphabet=cell(27,1);
Alphabet{1}= [0,1,0;1,0,1;1,1,1;1,0,1;1,0,1];
Alphabet{2}= [1,1,0;1,0,1;1,1,0;1,0,1;1,1,0];
Alphabet{3}= [1,1,1;1,0,1;1,0,0;1,0,1;1,1,1];
Alphabet{4}= [1,1,0;1,0,1;1,0,1;1,0,1;1,1,0];
Alphabet{5}= [1,1,1;1,0,0;1,1,1;1,0,0;1,1,1];
Alphabet{6}= [1,1,1;1,0,0;1,1,0;1,0,0;1,0,0];
Alphabet{7}= [1,1,1,1;1,0,0,0;1,0,1,1;1,0,0,1;1,1,1,1];
Alphabet{8}= [1,0,1;1,0,1;1,1,1;1,0,1;1,0,1];
Alphabet{9}= [1,1,1;0,1,0;0,1,0;0,1,0;1,1,1];
Alphabet{10}= [1,1,1,1,1;0,0,1,0,0;0,0,1,0,0;1,0,1,0,0;0,1,1,0,0];
Alphabet{11}= [1,0,0,1;1,0,1,0;1,1,0,0;1,0,1,0;1,0,0,1];
Alphabet{12}= [1,0,0;1,0,0;1,0,0;1,0,0;1,1,1];
Alphabet{13}= [1,1,0,1,1;1,0,1,0,1;1,0,1,0,1;1,0,0,0,1;1,0,0,0,1];
Alphabet{14}= [1,0,0,0,1;1,1,0,0,1;1,0,1,0,1;1,0,0,1,1;1,0,0,0,1];
Alphabet{15}= [1,1,1;1,0,1;1,0,1;1,0,1;1,1,1];
Alphabet{16}= [1,1,1;1,0,1;1,1,1;1,0,0;1,0,0];
Alphabet{17}=[1,1,1,1,1,0;1,0,0,0,1,0;1,0,1,1,1,0;...
              1,0,0,0,1,0;1,1,1,1,1,1];
Alphabet{18}= [1,1,1,0;1,0,1,0;1,1,0,0;1,0,1,0;1,0,0,1];
Alphabet{19}= [1,1,1;1,0,0;1,1,1;0,0,1;1,1,1];
Alphabet{20}= [1,1,1,1,1;0,0,1,0,0;0,0,1,0,0;0,0,1,0,0;0,0,1,0,0];
Alphabet{21}= [1,0,1;1,0,1;1,0,1;1,0,1;1,1,1];
Alphabet{22}= [1,0,1;1,0,1;1,0,1;1,0,1;0,1,0];
Alphabet{23}= [1,0,0,0,1;1,0,0,0,1;1,0,1,0,1;1,0,1,0,1;0,1,0,1,0];
Alphabet{24}= [1,0,1;1,0,1;0,1,0;1,0,1;1,0,1];
Alphabet{25}= [1,0,1;1,0,1;0,1,1;0,0,1;1,1,1];
Alphabet{26}= [1,1,1;0,0,1;0,1,0;1,0,0;1,1,1];
Alphabet{27}= [0;0;0;0;0];

for ii = 1:5
    for jj = 1:17
        Xc = (jj-1)*2*R;
        Yc = -(2*R)*(ii-1);
        B = My_LED_Circle_476436(R,Xc,Yc);
        hold on
        H(ii,jj) = fill(B(1,:),B(2,:),'w');
    end
end
axis equal
axis off