function[CircleXY] = My_LED_Circle_476436(R,Xc,Yc)
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    My_LED_Circle
%         by
%     Zach Yearout
%      476-436
%%%%%%%%%%%%%%%%%%%%%%%%%%

Theta = 0:0.00613:2*pi;
Xr = R*cos(Theta);
Yr = R*sin(Theta);
Xcircle = Xr.*ones(1,1025)+Xc;
Ycircle = Yr.*ones(1,1025)+Yc;
CircleXY = [Xcircle;Ycircle];
end
