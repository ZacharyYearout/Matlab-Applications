%%%%%%%%%%%%%%%%%%%%%%%
%
% This project shows the trajectory path of a satellite being launched into
% space. The goal was to show the path trajectory for multiple different
% cases with can be customized by chaning the size and mass of the
% satellite. Additionally, by looking at data of other planets the system
% can be established to run on other planets as well. This project was
% created for a class on Computational Methods
%
%%%%%%%%%%%%%%%%%%%%%%%


%Project3
clear,clc

global r_earth m A C_D
r_earth = 6371; %km, radius of the earth
m = 5; %kg, mass of satellite
A = 0.01; %m^2, frontal area of satellite
C_D = 2.2; %coefficient of drag

t_final = 50*3600; %seconds

r_0 = r_earth + 90; %km
theta_0 = pi/4; %rad

V_0 = 9.5; %km/s
phi_0 = 89.5; %deg, launch angle
v_r_0 = V_0 * cosd(phi_0); %km/s
v_theta_0 = V_0 * sind(phi_0); %km/s

r_dot_0 = v_r_0; %km/s
theta_dot_0 = v_theta_0 / r_0; %rad/s

y_0 = [r_0, theta_0, r_dot_0, theta_dot_0];
tspan = [0 t_final];
[t,Y] = ode45(@kinetics,tspan,y_0);
r = Y(:,1); %km
theta = Y(:,2); %rad
v_r = Y(:,3); %km/s, same as r_dot
v_theta = r.*Y(:,4); %rad/s, r * theta_dot

v_r(r<=r_earth) = 0;
v_theta(r<=r_earth) = 0;
V = sqrt(v_r.^2+v_theta.^2); %km/s
r(r<=r_earth) = r_earth;
R = r - r_earth;

figure(1),clf
polarplot(theta,r,'ro-')
hold on
polarplot(linspace(0,2*pi,100),r_earth*ones(1,100),'b-','LineWidth',2)
% rlim([0 r_earth+10000])

figure(2),clf
plot(t,R,'ro-')
ylim([0 1.1*max(R)])


function dydt = kinetics(t,y)

global r_earth m A C_D

r = y(1);
theta = y(2);
r_dot = y(3);
theta_dot = y(4);

R = r - r_earth; %km

v_r = r_dot; %km/s
v_theta = r*theta_dot; %km/s
V = sqrt( v_r^2 + v_theta^2 ); %km/s, velocity magnitude
D = 1/2*rho(R)*(V*1000)^2 * A * C_D; %N, atmospheric drag
D = D / 1000; %kN, equivalent to kg-km/s^2

dydt(1) = r_dot;
dydt(2) = theta_dot;
dydt(3) = r*theta_dot^2 - g(r) - D/m * v_r/V;
dydt(4) = -D/(m*r) * v_theta/V - 2/r * r_dot*theta_dot;
dydt = dydt';

if R <= 0, dydt = zeros(4,1); end %satellite has crashed

end



function gacc = g(r)
    %calculate the local gravitational acceleration
    m_earth = 5.972E24; %kg
    G = 6.67408E-11; %m^3/kg-s^2
    gacc = G*m_earth / (r*1000)^2; %m/s^2, r must be in km
    gacc = gacc/1000; %km/s^2
end

function density = rho(R)
    %calculate local atmospheric density
    if R < 0
        density = 999; return %satellite has crashed
    elseif R >= 0 && R < 11
        T = 15.04 - 0.00649*(R*1000);
        P = 101.29 * ((T+273.1)/288.08)^5.256;
    elseif R >= 11 && R <= 25
        T = -56.46;
        P = 22.65*exp(1.73 - 0.000157*(R*1000));
    else
        T = -131.21 + 0.00299*(R*1000);
        P = 2.488*((T+273.1)/216.6)^-11.388;
    end

    density = P / (0.2869*(T+273.1)); %kg/m^3    
end