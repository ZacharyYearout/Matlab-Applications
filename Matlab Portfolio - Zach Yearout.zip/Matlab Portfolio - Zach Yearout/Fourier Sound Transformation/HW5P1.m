%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This project takes a noisey signal and using a Fourier transformation
% reduces the noise and cleans the signal. It can be used to clean data
% with noise and identify the dominating frequencies of a signal
% Zach Yearout
%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all

y = load('noisysignal.txt');
Fs = 100000;
Ny = Fs/2;
N = length(y);
duration = N/Fs;
t = linspace(0,duration,N);

Y = fft(y);
N_unique = ceil((N+1)/2);
Y_unique = Y(1:N_unique);
f_range = linspace(0,Ny,N_unique);

figure(1),clf
stem(f_range,abs(Y_unique/N),'b')
xlim([0 600])

Y_filtered = Y;
Y_filtered((abs(Y)/N)<0.004) = 0;

y_filtered = ifft(Y_filtered);

figure(2),clf
plot(t,y,'b')
hold on
plot(t,y_filtered,'k')
xlim([0 0.015])
xlabel('time'),ylabel('y')

sound(y,Fs)
pause(duration+0.1)
sound(y_filtered,Fs)
