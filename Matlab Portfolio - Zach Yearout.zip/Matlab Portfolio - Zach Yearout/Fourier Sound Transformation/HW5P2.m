%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This function looks at a signal displayed through a Fourier
% transformation and displays the dominating frequencies. It uses an
% increasing number of terms in the Fourier transformation to get better
% approxiamtions for the dominant frequencies within the signal. It was
% developed as part of an assignment for Data Analysis
% Zach Yearout
%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all

% Part A
A = 0.5;
f = 200; %Hz
omega = 2*pi*f; %rad/s
t = linspace(0,4*pi/omega,1000); %s

figure(1), clf

y = A/pi + A/2*sin(omega*t);
for n = 1:1
    y = y - 2*A/pi * cos(2*n*omega*t)/(4*n^2-1);
end
plot(t,y,'r-')
hold on

y = A/pi + A/2*sin(omega*t);
for n = 1:2
    y = y - 2*A/pi * cos(2*n*omega*t)/(4*n^2-1);
end
plot(t,y,'b-','LineWidth',1)

y = A/pi + A/2*sin(omega*t);
for n = 1:100
    y = y - 2*A/pi * cos(2*n*omega*t)/(4*n^2-1);
end
plot(t,y,'k-','LineWidth',2)

axis square
xlabel('time (s)'), ylabel('y')

% Parts B and C
Fs = 10000; % elements played per second
Ny = Fs/2; % Nyquist frequency
duration = 2; % seconds, duration of tone
N = Fs*duration; % number of points in tone
t = linspace(0,duration,N);

y = A*cos(omega*t);
sound(y,Fs)
pause(duration+0.5)

y = A/pi + A/2*sin(omega*t);
for n = 1:100
    y = y - 2*A/pi * cos(2*n*omega*t)/(4*n^2-1);
end

sound(y,Fs)


% Part D

%4 terms
y = A/pi + A/2*sin(omega*t);
for n = 1:2
    y = y - 2*A/pi * cos(2*n*omega*t)/(4*n^2-1);
end

Y = fft(y);
N_unique = ceil((N+1)/2); %number of unique points in fft
Y_unique = Y(1:N_unique);
f_range = linspace(0,Ny,N_unique);

figure(2),clf
stem(f_range,abs(Y_unique/N),'b')
xlim([0 1000])
xlabel('frequency (Hz)'), ylabel('|Y| / N')

%102 terms
y = A/pi + A/2*sin(omega*t);
for n = 1:102
    y = y - 2*A/pi * cos(2*n*omega*t)/(4*n^2-1);
end

Y = fft(y);
Y_unique = Y(1:N_unique);

figure(3),clf
stem(f_range,abs(Y_unique/N),'b')
xlabel('frequency (Hz)'), ylabel('|Y| / N')


% Part E
% The first value at 0 Hz is called the offset, and should equal the magnitude
% of the first term (A/pi). The remaining spikes should be half as tall as
% each term in the series. The second term is A/2, the third term is
% (2*A/pi) / (4*1^2 � 1), etc.
% They should occur at frequencies of 0 Hz, omega/2*pi Hz, 2*omega/2*pi Hz, etc.
term1 = A/pi
term2 = A/2
term3 = (2*A/pi) / (4*1^2-1)
term4 = (2*A/pi) / (4*2^2-1)

f1 = 0
f2 = omega /(2*pi)
f3 = (2*1*omega) / (2*pi)
f4 = (2*2*omega) / (2*pi)