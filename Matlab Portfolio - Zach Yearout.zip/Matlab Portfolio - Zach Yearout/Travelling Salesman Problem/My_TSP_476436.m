%%%%%%%%%%%%%%%%%%%%%%%%
% My_TSP
% This project creates a randomly generated map of m points or cities which
% challenges the user to find the shortest path among all cities by
% clicking on them. It is designed to find the optimal shortest path and
% compare the optimal path to the user's chosen path. Due to the
% randomization of the cities, the map is different every time and so is
% the optimal path, allowing for a fun, interactive project. This was made
% for a Computational Methods class
% Zach Yearout
%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc
global City
global count
count = 1;
m = 9; %Practice m
ii = 1;

%Establishes the random cities
for ii=1:m
        City(ii,1) = rand(1)*10;
        City(ii,2) = rand(1)*10;
    ii = ii + 1;
end
%Plots the random cities
for ii = 1:m
    plot(City(ii,1),City(ii,2),'b.','MarkerSize',18)
    hold on
    text(City(ii,1)+0.075,City(ii,2)+0.075,num2str(ii),'FontSize',14)
    axis([0, 10, 0, 10])
end

set(gcf,'WindowButtonUpFcn','User_Input')
set(gca,'Units','Pixels')


