Click = get(gca,'CurrentPoint');
Point = Click(1,1:2);
tol = 0.5;
Distance_click = sqrt((City(1:m,1)-Point(1,1)).^2 + (City(1:m,2)-Point(1,2)).^2);
Min_click = min(Distance_click);
%Checks if click is close to a town and builds the user's path
if Min_click < tol
    Closest_city = find(Min_click==Distance_click);
    plot(City(Closest_city,1),City(Closest_city,2),'bo','MarkerSize',24)
    User_path(count,1) = Closest_city;
    %Checks if a city is clicked twice
    if count >= 2
       if User_path(count,1) == User_path(count-1,1)
           User_path(count,1) = User_path(count-1,1);
           disp('Please don''t choose the same city twice')
       end
    end
    count = count + 1;
else
    %Checks if a click is to far from any possible cities
    disp('Please click closer to a city')
end
%Plots the user path and calculates the user distance
while count == m + 1
    ii = 1;
    for ii = 1:m-1
        User_distance(ii,1) = sqrt([(City(User_path(ii,1),1))-(City(User_path(ii+1,1),1))]^2+...
            [(City(User_path(ii,1),2))-(City(User_path(ii+1,1),2))]^2);
    end
    for ii=1:m
        Plot_user_x(ii) = City(User_path(ii,1),1);
        Plot_user_y(ii) = City(User_path(ii,1),2);
    end
    Last_points = [(City(User_path(1,1),1)) (City(User_path(1,1),2)); (City(User_path(m,1),1)) (City(User_path(m,1),2))];
    plot(Plot_user_x,Plot_user_y,'r-')
    plot(Last_points(:,1),Last_points(:,2),'r-')
    Final_user = sqrt([(City(User_path(1,1),1))-(City(User_path(m,1),1))]^2+...
    [(City(User_path(1,1),2))-(City(User_path(m,1),2))]^2);

User_total = sum(User_distance) + Final_user;

disp('Your total path length is')
disp(num2str(User_total))

run('Optimal_Distance')
break
end




