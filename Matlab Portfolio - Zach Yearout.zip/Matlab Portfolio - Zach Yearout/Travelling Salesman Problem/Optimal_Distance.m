%Shortest distance between two cities
Towns = 1:1:m;
Routes = perms(Towns);
Distance = City(Routes);
ii = 1;
jj = 1;
temp = find(Routes(:,1)==(m-1),1);
%Calculates the distance over the shortest path
for ii = 1:temp-1
    for jj = 1:m-1
        Town_1 = Routes(ii,jj);
        Town_2 = Routes(ii,jj+1);
        Distance_Towns(ii,jj) = sqrt([(City(Town_1,1))-(City(Town_2,1))]^2+...
        [(City(Town_1,2))-(City(Town_2,2))]^2);
        jj = jj + 1;
    end
    ii = ii + 1;
end
Distance_3pts = sum(Distance_Towns')';
%Calculates the distance of the shortest path, from end to beginning
for ii = 1:temp-1
    Final_Towns(ii) = sqrt([(City(Routes(ii,1),1))-(City(Routes(ii,m),1))]^2+...
    [(City(Routes(ii,1),2))-(City(Routes(ii,m),2))]^2);
    ii = ii + 1;
end
Final_Towns = Final_Towns';
Final_Distance = Distance_3pts + Final_Towns;
Shortest_Distance = min(Final_Distance);
Shortest_Route = find(Final_Distance==Shortest_Distance);
Optimal_Path = Routes(Shortest_Route,:)';
Optimal_Path = Optimal_Path(:,1);
%Plots the optimal path
figure(1)
plot(City(Optimal_Path,1),City(Optimal_Path,2),'g--')
plot([City(Optimal_Path(m,:),1) City(Optimal_Path(1,:),1)],... 
    [City(Optimal_Path(m,:),2) City(Optimal_Path(1,:),2)],'g--')
%Displays optimal path length
disp('The optimal path distance is')
disp(num2str(Shortest_Distance))

if abs(User_total - Shortest_Distance)<=.001
    disp('Congrats you found the optimal path')
end


        