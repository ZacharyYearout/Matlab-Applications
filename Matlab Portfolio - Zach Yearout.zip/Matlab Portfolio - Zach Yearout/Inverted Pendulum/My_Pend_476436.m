%%%%%%%%%%%%%%%%%%%%%%%%%
%    My_Pend_476436
%         by
%    Zach Yearout
%%%%%%%%%%%%%%%%%%%%%%%%%
function ddZZ = My_Pend_476436(tt, ZZ,Xd)
% ZZ = [0,0,pi,0];
M = 0.5; % kg
m = 0.2; % kg
b = 0.1; % N/m
l = 0.3; % m
I = 0.006; % kg*m^2
g = 9.81; % m/s^2
N = -70.7107;
k1 = -70.7107;
k2 = -37.8345;
k3 = -105.5298;
k4 = 20.9238;
Phi = pi - ZZ(3);

F = N*Xd-(k1*ZZ(1)+k2*ZZ(2)+k3*Phi+k4*ZZ(4));
AA = ((I+m*l^2)*(b*ZZ(2)-F-m*l*ZZ(4)^2*sin(ZZ(3)))-m^2*g*l^2*sin(ZZ(3))*cos(ZZ(3)));
BB = (m^2*l^2*cos(ZZ(3))^2-(I+m*l^2)*(M+m));
ddXX = AA/BB;
CC = (-m*l*ddXX*cos(ZZ(3))-m*g*l*sin(ZZ(3)));
DD = (I+m*l^2);
ddtheta = CC/DD;
ddZZ = [ZZ(2);ddXX;ZZ(4);ddtheta];

end
