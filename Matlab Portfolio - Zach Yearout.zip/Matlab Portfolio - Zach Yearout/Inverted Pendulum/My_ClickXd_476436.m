%%%%%%%%%%%%%%%%%%%%%%%%%
%    My_ClickXd_476436
%         by
%    Zach Yearout
%%%%%%%%%%%%%%%%%%%%%%%%%

global FinalXd;
get(gcf,'WindowButtonUpFcn');
out = get(gca,'CurrentPoint');
DownX = out(1,1);


Zint = [FinalXd,0,pi,0];
ttSpan = 0:0.01:2.5;
ttStep = ttSpan(2)-ttSpan(1);
[tout, yout] = My_RK4_476436('My_Pend_476436',ttSpan,Zint,DownX);

%Position
subplot(2,2,1)
xlabel('Time (s)')
ylabel('Position (m)')
title('Pendulum position vs time')
%Phi
subplot(2,2,3)
xlabel('Time (s)')
ylabel('Phi (rad)')
title('Phi vs time')

for ii = 1:length(tout)
%Cart body
CartX= [-.5+yout(ii,1),.5+yout(ii,1),.5+yout(ii,1),-.5+yout(ii,1),-.5+yout(ii,1)];
CartY= [.2,.2,.5,.5,.2];
%Wheels
Circle = 0:0.01:2*pi;
Radius = 0.1;
xRadius1 = cos(Circle)*Radius+0.5+yout(ii,1);
yRadius1 = sin(Circle)*Radius+0.1;
xRadius2 = cos(Circle)*Radius-0.5+yout(ii,1);
yRadius2 = sin(Circle)*Radius+0.1;
%Pendulum
PendX= [-.01+yout(ii,1),.01+yout(ii,1),.01+yout(ii,1)+0.3*sin(pi-yout(ii,3)),...
    -.01+yout(ii,1)+0.3*sin(pi-yout(ii,3)),-.01+yout(ii,1)];
PendY= [0.5,0.5,0.8+(0.3*cos(pi-yout(ii,3))),0.8+(0.3*cos(pi-yout(ii,3))),0.5];
%Pivot
Rbig = 0.05;
Rsmall = 0.01;
HalfCircle = 0:0.01:pi;
PinX1 = cos(HalfCircle)*Rbig+yout(ii,1);
PinY1 = sin(HalfCircle)*Rbig+0.5;
PinX2 = cos(Circle)*Rsmall+yout(ii,1);
PinY2 = sin(Circle)*Rsmall+0.5;


%Plots the moving cart
subplot(2,2,[2 4])
axis([-2 2 -1 3])
fill(CartX,CartY,'b',xRadius1,yRadius1,'k',xRadius2,yRadius2,'k',PendX,PendY,'r',PinX1,PinY1,'b',PinX2,PinY2,'k')
%Cart
subplot(2,2,[2 4])
xlabel('Position (m)')
ylabel('Position (m)')
title('Cart')
axis([-1 1 0 1.5])
axis square

%Position versus time plot
subplot(2,2,1)
axis([0 2.5 -0.5 0.5])
hold on
plot(tout(ii),yout(ii,1),'k.')
plot([0 3],[0 0],'k--')
%Phi versus time plot
subplot(2,2,3)
axis([0 2.5 -0.5 0.5])
hold on
plot(tout(ii),pi-yout(ii,3),'k.')
plot([0 3],[0 0],'k--')

pause(0.01)
set(gcf,'Position',[100 100 1000 600])
FinalXd = yout(ii,1);
end
display('You can now click to change the cart''s position again')