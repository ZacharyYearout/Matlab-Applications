%%%%%%%%%%%%%%%%%%%%%%%%%
%    My_RK4_476436
%         by
%    Zach Yearout
%%%%%%%%%%%%%%%%%%%%%%%%%

function [tout,Zout] = My_RK4_476436(func,ttSpan,Zint,Xd)
Zout(1:4,1) = Zint;
ttSpan = 0:0.01:2.5;
ttStep = ttSpan(2)-ttSpan(1);

for ii = 1:length(ttSpan)
     k1 = ttStep*My_Pend_476436(ii,Zout(1:4,ii),Xd);
     k2 = ttStep*My_Pend_476436(ii+ttStep/2,Zout(1:4,ii)+k1/2,Xd);
     k3 = ttStep*My_Pend_476436(ii+ttStep/2,Zout(1:4,ii)+k2/2,Xd);
     k4 = ttStep*My_Pend_476436(ii,Zout(1:4,ii)+k3,Xd);
     Zout(1:4,ii+1) = Zout(1:4,ii)+(1/6)*k1+(1/3)*k2+(1/3)*k3+(1/6)*k4;  
end
tout = ttSpan';
Zout = Zout';
end
