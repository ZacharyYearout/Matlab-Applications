% My_ClickDown_476436
ClickDown = get(gca,'CurrentPoint');
PointDown = ClickDown(1,1:2);