% My_KeyPress_476436
F1 = figure(1);
AA = get(F1,'CurrentKey');
%closes the window
if AA == 'x'
    close all
%sets the translate icon
elseif AA == 't'
    set(gcf,'Pointer','hand')
%sets the scale icon
elseif AA == 's'
    set(gcf,'Pointer','circle')
%sets the rotate icon
elseif AA == 'r'
    set(gcf,'Pointer','fleur')
%resets the graph
elseif AA == 'q'
    hold off
    Shape = [-1 0 1 0 0; 0 1 0 -2 0; 1 1 1 1 1];
    refresh
    Center = [0;0];
    plot(Shape(1,1:4),Shape(2,1:4),'b')
    hold on 
    plot([Shape(1,4) Shape(1,1)],[Shape(2,4) Shape(2,1)],'b')
    axis ([-3 3 -3 3])
    axis square
% sets the cursor back to normal 
else
    set(gcf,'Pointer','arrow')
end