% My_ClickUp_476436
ClickUp = get(gca,'CurrentPoint');
PointUp = ClickUp(1,1:2);
F1 = figure(1);
AA = get(F1,'CurrentKey');
%translates the object
if AA == 't'
    Translate = PointUp - PointDown;
    Shape(1,:) =  Shape(1,:) + Translate(1,1);
    Shape(2,:) = Shape(2,:) + Translate(1,2);
    plot([Center(1,1) Center(1,1)+Translate(1,1)],[Center(2,1) Center(2,1)+Translate(1,2)],'g')%Plots diagonal of triangle
    plot([Center(1,1) Center(1,1)+Translate(1,1)],[Center(2,1) Center(2,1)],'r')%Plots x-part of triangle
    plot([Center(1,1)+Translate(1,1) Center(1,1)+Translate(1,1)],[Center(2,1) Center(2,1)+Translate(1,2)],'y')%Plots y-part of triangle
    Center = Center + Translate';
    pause(0.25)
    hold off
    plot(Shape(1,1:4),Shape(2,1:4),'b')
    hold on
    plot([Shape(1,4) Shape(1,1)],[Shape(2,4) Shape(2,1)],'b')
    axis([-3 3 -3 3])
    axis square
end
%scales the object
if AA == 's'
    R1 = abs(Center) + abs(PointDown');
    R1final = sqrt(R1(1,1)^2+R1(2,1)^2);
    R2 = abs(Center) + abs(PointUp');
    R2final = sqrt((R2(1,1)^2)+(R2(2,1)^2));
    Scale = R2final/R1final;
    theta = 0:0.01:2*pi;
    Circle1x= R1final*cos(theta);
    Circle1y= R1final*sin(theta);
    Circle2x= R2final*cos(theta);
    Circle2y= R2final*sin(theta);
    plot(Circle1x+Center(1,1),Circle1y+Center(2,1),'k')%inner circle
    plot(Circle2x+Center(1,1),Circle2y+Center(2,1),'k')%outer circle
    pause(0.25)
    %Translates the shape to the origin and back
    TranslateCenterX = Shape(1,5).*ones(1,5);
    TranslateCenterY = Shape(2,5).*ones(1,5);
    Translate = [TranslateCenterX; TranslateCenterY; 0 0 0 0 0];
    Shape1 = Shape-Translate;
    Shape2 = Shape1.*Scale;
    Shape = Shape2+Translate;
    %Plots shape
    hold off
    plot(Shape(1,1:4),Shape(2,1:4),'b')
    hold on
    plot([Shape(1,4) Shape(1,1)],[Shape(2,4) Shape(2,1)],'b')
    axis([-3 3 -3 3])
    axis square
end
%rotates the object
if AA == 'r'
    Vector1 = [PointDown(1,1)-Center(1,1) PointDown(1,2)-Center(2,1) 0];
    Vector2 = [PointUp(1,1)-Center(1,1) PointUp(1,2)-Center(2,1) 0];
    DotVectors = dot(Vector1,Vector2);
    NormVectors= norm(Vector1)*norm(Vector2);
    Theta = acosd(DotVectors/NormVectors);
    CrossVector = cross(Vector1,Vector2);
    if CrossVector(3)<0
        Theta=-Theta;
    end
    Rotation = [cosd(Theta) -sind(Theta) 0; sind(Theta) cosd(Theta) 0; 0 0 1];
    %Traslates the shape
    TranslateCenterX2 = Shape(1,5).*ones(1,5);
    TranslateCenterY2 = Shape(2,5).*ones(1,5);
    Translate2 = [TranslateCenterX2; TranslateCenterY2; 0 0 0 0 0];
    Shape1 = Shape-Translate2;
    Shape2 = Rotation*Shape1;
    Shape = Shape2+Translate2;
    %Plots Vectors
    plot([Center(1,1) Vector1(1)],[Center(2,1) Vector1(2)],'r')
    plot([Center(1,1) Vector2(1)],[Center(2,1) Vector2(2)],'r')
    pause(0.25)
    %Plots new shapes
    hold off
    plot(Shape(1,1:4),Shape(2,1:4),'b')
    hold on
    plot([Shape(1,4) Shape(1,1)],[Shape(2,4) Shape(2,1)],'b')
    axis([-3 3 -3 3])
    axis square
end

