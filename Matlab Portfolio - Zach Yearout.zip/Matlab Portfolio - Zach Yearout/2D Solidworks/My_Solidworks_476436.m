%%%%%%%%%%%%%%%%%%%%%
% My_Solidworks
% This project is designed to act as a 2D version of solidworks, allowing
% the user to rotate, translate, and scale a geometric shape. This is done
% by taking keyboard inputs from the user such as the letter "r" for
% rotate, "t" for translate, and "s" for scale. The project is additionally
% designed to show the user how their choice will affect the shape prior to
% the action happening, to help them better understand how their input
% effects the outcome. This project was made for a class on Computational
% Analysis
% Zach Yearout
%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc
global Shape Center 
set(gca,'units','pixels')
AxisPixels = get(gca,'position');
set(gcf,'WindowButtonDownFcn','My_ClickDown_476436')
set(gcf,'WindowButtonUpFcn','My_ClickUp_476436')
set(gcf,'keypressfcn','My_KeyPress_476436')
Shape = [-1 0 1 0 0; 0 1 0 -2 0; 1 1 1 1 1];
refresh
Center = [0;0];
plot(Shape(1,1:4),Shape(2,1:4),'b')
hold on 
plot([Shape(1,4) Shape(1,1)],[Shape(2,4) Shape(2,1)],'b')
axis ([-3 3 -3 3])
axis square