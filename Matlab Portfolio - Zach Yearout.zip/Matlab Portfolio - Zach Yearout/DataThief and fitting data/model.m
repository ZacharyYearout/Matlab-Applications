function [Y] = model(coeff,X)

% Problem 2
%% Comment all code in this section to run problem three
Y = coeff(1).*exp(-X./coeff(2));  %exponential decay
%%

% %Problem 3
% %% Uncomment all code in this section to run problem three
% X0 = 0.1; %m
% Mass = 1; %kg
% Wn = sqrt(coeff(1)/Mass);
% Zeta = coeff(2)/(2*sqrt(coeff(1)*Mass));
% Wd = Wn*sqrt(1-(Zeta^2));
% A = sqrt(((Wn*Zeta*X0/Wd)^2) + (X0^2));
% Phi = atan(Wd/(Zeta*Wn));
% Y = A*exp(-Zeta*Wn*X).*sin((Wd*X)+Phi);  %displacement response
%%

end
