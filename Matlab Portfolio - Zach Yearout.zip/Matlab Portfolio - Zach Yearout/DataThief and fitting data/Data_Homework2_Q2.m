%%%%%%%%%%%%%%%%%%%%%%
%
% This project uses a program known as DataTheif to recreate the results
% found from an online study. It looks at the fitted values of variables k
% and c as they relate to the height of beer foam in a glass. Additionally,
% problem 3 which requires uncommenting all sections listed as problem 3
% and commenting all sections listed as problem 2 shows the displacement of
% a spring with respect to time with a best fit line as well to match the
% given data dispvst.mat. This project was made for a class on Data
% Analysis
% Zach Yearout
%%%%%%%%%%%%%%%%%%%%%%

function Data_Homework2_Q2
clear all, close all, clc

%Problem 2
%% Comment all code in this section to run problem three
Data = xlsread('MCEN3047_Homework2_Q2_DataThief.xlsx');
X = Data(:,2);
Y = Data(:,1);
Tau = [300 50];
%%

%Problem 3
% %% Uncomment all code in this section to run problem three
% load('dispvst.mat')
% X = dispvst(:,2);
% Y = dispvst(:,1);
% Tau = [10 5];
%%

%Code to produce a linear fit
figure(1)
plot(X,Y,'ko')
hold on
Point = nlinfit(X,Y,@model,Tau);

%Problem 2
%% Comment all code in this section to run problem three
fit = model(Point,X);
plot(X,fit)
grid on
xlabel('Time (s)')
ylabel('Height (cm)')
disp('The measured value for Tau is')
disp(fit(end,1))
%%

%Problem 3
% %% Uncomment all code in this section to run problem three
% x = 0:.001:5;
% fit = model(Point,x);
% plot(x,fit)
% grid on
% xlabel('Time (s)')
% ylabel('Position (m)')
%%
disp('The measured value for k and c respectively are')
disp(Point)


end
