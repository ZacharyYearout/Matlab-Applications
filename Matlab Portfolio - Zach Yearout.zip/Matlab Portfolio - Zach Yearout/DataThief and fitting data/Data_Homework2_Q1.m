%%%%%%%%%%%%%%%%%%%%%%%
%
% This project shows the difference in tensile strength of theoretical pipe
% samples of different diameter. It shows the difference from the
% calculated mean of the expected strength in pipe from the data collected.
% This project was made for a Data Analysis class
% Zach Yearout
%%%%%%%%%%%%%%%%%%%%%%%

clear all; close all, clc

A = [4.2,51; 4.4,54; 4.6,69; 4.8,81; 5.0,75; 5.2,79; 5.4,89; 5.6,101; 5.8,98; 6.0,102];

Y = A(:,2);
X = A(:,1);

a = ((sum(Y)*sum(X.^2))-(sum(X)*sum(X.*Y)))/((length(X)*sum(X.^2))-sum(X)^2);
b = (length(X)*sum(X.*Y)-sum(X)*sum(Y))/((length(X)*sum(X.^2))-sum(X)^2);
hold on
scatter(X,Y,'ko')
xlabel('Diameter (mm)')
ylabel('Strength (kN/mm)')
grid on
Xpoints = [4.2:0.01:6];
Ypoints = a+b.*Xpoints;
plot(Xpoints,Ypoints)

%Calculate r^2 for goodness fit
AvgY = mean(Y);
AvgX = mean(X);
YHAT2 = a+b*X;
Rsquared = (sum((Y-AvgY).^2)-sum((Y-YHAT2).^2))/(sum((Y-AvgY).^2));
disp('The calculated value for R squared is')
disp(Rsquared)

%Calculate the residuals for points
for i = 1:length(X)
    YHAT(i) = a+b*X(i);
    residuals(i) = Y(i)-YHAT(i);
end
%Plot of residuals
figure
Arb = [50:0.1:110];
Zero = zeros(1,length(Arb));
plot(Y,residuals,'ko')
hold on
plot(Arb,Zero,'k--')
grid on
xlabel('Strength (kN/mm)')
ylabel('Residual from calculated value')

deltaDiam = 0.3;
deltaStren = b*0.3;
disp('By increasing the diameter by 0.3mm, the strength should increase by')
disp(deltaStren)

Strength55 = a+b*5.5;
disp('If the diameter is set at 5.5mm the predicted strength should be')
disp(Strength55)

