function [z] = Calculate(P,A)

Fp = 0.9803+0.018*(P/10)+0.0017*(P/100)^2;
Cb = exp(11.667-0.8709*log(A)+0.09005*(log(A))^2);
z = [Cb,Fp];

end