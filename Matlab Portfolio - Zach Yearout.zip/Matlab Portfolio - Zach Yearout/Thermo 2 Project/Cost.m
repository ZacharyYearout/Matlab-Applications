function [Price] = Cost(Cb,Fm,Fp,Fl)

Price = Cb*Fm*Fp*Fl;

end