%%%%%%%%%%%%%%%%%%%%%%
%
% This is a project done for a Thermodynamics 2 class about a theoretical
% power plant that could be built. A team and I designed all aspects of the
% plant including the cycle and operating conditions that plant would work
% under and then calculated the state of the working fluid at all points
% through the system. In addition, the cost of each piece of equipment
% within the system was calcualted using equations given for the standard
% cost of machinery necessary based on four factors: Cb, Fm, Fp, and Fl.
% The results of these findings were documented and present as the final
% project to this class
% Zach Yearout
%%%%%%%%%%%%%%%%%%%%%%

clear all;close all;clc;
Aboiler = 3.903 *10.7639;
Pboiler = 6000 *0.145;

Acfwh = 0.1486 *10.7639;
Pcfwh = 10 *0.145;

Acond = 12.93 *10.7639;
Pcond = 16500 *0.145;

Areheat = 1.982 *10.7639;
Preheat = 16500 *0.145;

Fm = 1;
Fl = 1;

[Boil] = Calculate(Pboiler,Aboiler);
[CFWH] = Calculate(Pcfwh,Acfwh);
[Cond] = Calculate(Pcond,Acond);
[Reheat] = Calculate(Preheat,Areheat);

format shortEng

BoilerCost = Cost(Boil(1),1,Boil(2),1)
CFWHCost = Cost(CFWH(1),1,CFWH(2),1)
CondCost = Cost(Cond(1),1,Cond(2),1)
ReheatCost = Cost(Reheat(1),1,Reheat(2),1)

