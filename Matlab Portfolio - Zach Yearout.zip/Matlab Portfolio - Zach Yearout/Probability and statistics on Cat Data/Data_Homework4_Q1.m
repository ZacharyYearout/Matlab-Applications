%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This project shows different probability data on a set of cat data given.
% It evaluates the standard deviation and mean on two sets of data and
% shows variance amongst the data through multiple histograms, bar plots,
% box plots, normalization plots, and the probability distribution
% function. It was developed for a Data Analysis class
% Zach Yearout
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Problem 1
clear all;close all;clc
%Data
MEOW = xlsread('cat_data');
IndoorCat = MEOW(:,1);
OutdoorCat = MEOW(:,2);
%Mean and Std 
MeanIn = mean(IndoorCat)
MeanOut = mean(OutdoorCat)
MedianIn= median(IndoorCat)
MedianOut = median(OutdoorCat)
StdIn = std(IndoorCat)
StdOut = std(OutdoorCat)
%Mean total and Std total
mean_tot = [MeanIn,MeanOut];
std_tot = [StdIn,StdOut];
X_stuff = categorical({'Mean Indoor','Mean Outdoor'});
%Bar graphs of mean of data
bar(X_stuff,mean_tot)
hold on
ylim([0 15])
xlabel('Individual Cats')
ylabel('Weight of Indoor Cats')
errorbar(mean_tot,std_tot,'.');
%Box plots
figure
subplot(1,2,1)
boxplot(IndoorCat)
subplot(1,2,2)
boxplot(OutdoorCat)
%Histograms
ConfInt = 0.7;
N = 20;
figure
histogram(IndoorCat,'Normalization', 'pdf','Binwidth',.7)
xlabel('Indoor Cats')
figure
histogram(OutdoorCat,'Normalization', 'pdf','Binwidth',.7)
xlabel('Outdoor Cats')
%Norm plots
figure
normplot(IndoorCat)
figure
normplot(OutdoorCat)
%PDF
Probability = fitdist(IndoorCat,'Normal');
Xvals = min(IndoorCat):1:max(IndoorCat);
Z = pdf(Probability,Xvals);
plot(Xvals,Z,'-k','Linewidth',3);
figure
Probability2 = fitdist(OutdoorCat,'Normal');
Xvals2 = min(OutdoorCat):1:max(OutdoorCat);
Z = pdf(Probability2,Xvals2);
plot(Xvals2,Z,'-k','Linewidth',3);