%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This project examines the statistics of rolling both a fair die and a
% loaded die. It uses the Central Limit Theorem to show how after enough
% time all results align with the Probability Mean Function. It was
% developed for a Data Analysis class
% Zach Yearout
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Problem 4
%Part 1
Die = 1:6;
Chance = [1/6, 1/6, 1/6, 1/6, 1/6, 1/6];
figure(1)
stem(Die,Chance);
axis([0 10 0 0.5])
xlabel('Die values: 1 to 6')
ylabel('Chance of happening')
grid on
Axis = gca;
Axis.Units = 'inches'
Axis.Position = [1 1 5 4];
Axis.FontSize = 12;
Axis.LineWidth = 1.5;
Axis.Box = 'on';
Variety = var(Die);
mean_val = mean(Die);
fprintf('The variance of the PMF is %i\n\n',Variety);
fprintf('The mean of the PMF is %i\n\n',mean_val);

for i = 1:100
    roll(i) = randi(6);
end
figure(2)
histogram(roll);
xlabel('Die values: 1 to 6')
ylabel('Chance of happening')
grid on
Axis = gca;
Axis.Units = 'inches'
Axis.Position = [1 1 5 4];
Axis.FontSize = 12;
Axis.LineWidth = 1.5;
Axis.Box = 'on';
%The two graphs look relatively the same and thus are a good approximation
%of each other, however the rand function does have a preferance which is
%different the the expected output

%Part 2
for j = 1:100
    roll2(j) = randi(6);
    roll3(j) = randi(6);
    rollsum(j) = roll2(j)+roll3(j);
end
figure(3);
histogram(rollsum)
xlabel('Die values: 1 to 12')
ylabel('Chance of happening')
grid on
Axis = gca;
Axis.Units = 'inches'
Axis.Position = [1 1 5 4];
Axis.FontSize = 12;
Axis.LineWidth = 1.5;
Axis.Box = 'on';
xlabel('Die value: 1 to 12')
ylabel('Count')
%By looking at the plots for rolling two dice, it starts to become more
%evident that the values in the middle will occur more than the values on
%the end. This makes sense based off of probablity

%Part 3
rolls1000 = randi(6,[1000 100]);
totalrolls = sum(rolls1000);
figure(4)
histogram(totalrolls);
grid on
Axis = gca;
Axis.Units = 'inches'
Axis.Position = [1 1 5 4];
Axis.FontSize = 12;
Axis.LineWidth = 1.5;
Axis.Box = 'on';
xlabel('Die value: 1000 to 6000')
ylabel('Count')
%By looking at the figure for rolling 1000, the probabilty now looks more
%similar to a bell curve than in the previous examples. By increasing the
%number of iterations, it appears to follow probability, wHAt?

%Part 4
figure(5)
histogram(totalrolls,'Binwidth',25,'Normalization','pdf');
hold on
Probability = fitdist(totalrolls','Normal');
Xvals = min(totalrolls):12.5:max(totalrolls);
Z = pdf(Probability,Xvals);
plot(Xvals,Z,'-k','Linewidth',3);
grid on
grid minor
Axis = gca;
Axis.Units = 'inches'
Axis.Position = [1 1 5 4];
Axis.FontSize = 12;
Axis.LineWidth = 1.5;
Axis.Box = 'on';
xlabel('Sum of Dice')
ylabel('Density')
hold off
Mean=Probability.mu;
Variance = (Probability.sigma)^2;
fprintf('The variance of the PDF is %i\n\n',Variance);
fprintf('The mean of the PDF is %i\n\n',Mean);
%The variance in the PMF is zero, while the variance in the PDF is 3501
%The mean of the PMF is 1/6, while the mean in the PDF is 2896
%This indicates the values of the PMF are much smaller than the PDF

%Part 5
%Loaded die
%If the previous experiment were repeated using a loaded die instead, the
%expected results should be the same due to the CLT and how even a loaded
%die should follow a normal distribution if rolled enough times
figure(6)
histfit(totalrolls)
xlabel('Dice sum')
ylabel('Number of Occurances')
grid on
grid minor
Axis = gca;
Axis.Units = 'inches'
Axis.Position = [1 1 5 4];
Axis.FontSize = 12;
Axis.LineWidth = 1.5;
Axis.Box = 'on';
