%%%%%%%%%%%%%%%%%%%%
% This simple project uses Matlab's predefined function 'flow' to create a
% representation of a jet flame. It also adds color highlighting to the
% display to help the user graphically see the variation in temperature
% through the system. This project was created for a class on Computational
% Methods
% Zach Yearout
%%%%%%%%%%%%%%%%%%%%

clear all, close all

[x,y,z,v] = flow;

xmin = min(x(:)); 
ymin = min(y(:)); 
zmin = min(z(:));

xmax = max(x(:)); 
ymax = max(y(:)); 
zmax = max(z(:));


hslice = surf(linspace(xmin,xmax,100),linspace(ymin,ymax,100),zeros(100));
xdd = get(hslice,'XData');
ydd = get(hslice,'YData');
zdd = get(hslice,'ZData');

rotate(hslice,[1,0,0],45)
xd = get(hslice,'XData');
yd = get(hslice,'YData');
zd = get(hslice,'ZData');
delete(hslice)

colormap(flipud(hot))
h = slice(x,y,z,v,xd,yd,zd);
set(h,'EdgeColor','None')
set(h,'FaceColor','interp')

hold on
hx = slice(x,y,z,v,xmax/2,[],[]);
set(hx,'EdgeColor','None')
set(hx,'FaceColor','interp')

hx = slice(x,y,z,v,xmax,[],[]);
set(hx,'EdgeColor','None')
set(hx,'FaceColor','interp')

hy = slice(x,y,z,v,[],ymax,[]);
set(hy,'EdgeColor','None')
set(hy,'FaceColor','interp')

hz = slice(x,y,z,v,[],[],zmin);
set(hz,'EdgeColor','None')
set(hz,'FaceColor','interp')

daspect([1,1,1])
axis tight
view(-30,20)
% colorbar
%camzoom(0.5)
%camproj orthographic
%pause
%camproj perspective
xlabel('x','FontSize',12,'FontWeight','bold')
ylabel('y','FontSize',12,'FontWeight','bold')
zlabel('z','FontSize',12,'FontWeight','bold')